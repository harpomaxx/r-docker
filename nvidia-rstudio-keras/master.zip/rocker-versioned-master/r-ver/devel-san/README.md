## rocker/r-ver:devel-san

This tag is experimental.  Please use `rocker/r-devel-san` for production use and testing of the current devel version of R with sanatizers.  


